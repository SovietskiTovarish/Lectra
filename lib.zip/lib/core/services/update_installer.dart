import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Downloads an update APK and hands it to the Android package
/// installer via [OpenFilex], which resolves to an
/// `ACTION_VIEW`/`ACTION_INSTALL_PACKAGE` intent for `.apk` MIME
/// types. This is the standard sideload-install mechanism used by
/// F-Droid and similar non-Play-Store apps.
class UpdateInstaller {
  UpdateInstaller({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Downloads the APK at [downloadUrl] and launches the system
  /// installer. Returns `true` if the installer was launched.
  ///
  /// The user must still tap "Install" in the system dialog — Android
  /// does not permit a normal app to install packages without that
  /// confirmation unless it holds device-owner privileges.
  Future<bool> downloadAndInstall(String downloadUrl) async {
    final request = http.Request('GET', Uri.parse(downloadUrl));
    final response = await _client.send(request);
    if (response.statusCode != 200) return false;

    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'lectra-update.apk'));
    final sink = file.openWrite();
    await response.stream.pipe(sink);
    await sink.close();

    final result = await OpenFilex.open(file.path);
    return result.type == ResultType.done;
  }

  void dispose() => _client.close();
}