import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lectra/core/constants/route_paths.dart';
import 'package:lectra/features/attendance/controller.dart';
import 'package:lectra/features/subjects/controller.dart';
import 'package:lectra/features/subjects/model.dart';
import 'package:lectra/shared/widgets/attendance_pie_chart.dart';

/// Lists all subjects with their overall attendance percentage and
/// opens the subject detail route when tapped.
class SubjectsScreen extends ConsumerWidget {
  const SubjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final subjectsAsync = ref.watch(subjectsControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Subjects')),
      body: subjectsAsync.when(
        data: (subjects) => _SubjectsList(subjects: subjects),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => Center(child: Text('Error: $error')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.pushNamed(RouteNames.addSubject),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _SubjectsList extends ConsumerWidget {
  const _SubjectsList({required this.subjects});

  final List<SubjectItem> subjects;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (subjects.isEmpty) {
      return const Center(child: Text('No subjects yet. Tap + to add one.'));
    }
    return ListView.builder(
      itemCount: subjects.length,
      itemBuilder: (context, index) {
        final subject = subjects[index];
        final statsAsync =
            ref.watch(subjectAttendanceStatsProvider(subject.id));
        final percentage = statsAsync.valueOrNull?.percentage ?? 0;
        return ListTile(
          leading: AttendancePieChart(
            percentage: percentage,
            size: 44,
            color: subject.accentColor,
          ),
          title: Text(subject.displayName),
          subtitle: subject.nickname != null && subject.nickname!.isNotEmpty
              ? Text(subject.name)
              : null,
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                tooltip: 'Edit subject',
                onPressed: () => context.pushNamed(
                  RouteNames.editSubject,
                  pathParameters: {'id': '${subject.id}'},
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                tooltip: 'Delete subject',
                onPressed: () => ref
                    .read(subjectsControllerProvider.notifier)
                    .deleteSubject(subject.id),
              ),
            ],
          ),
          onTap: () => context.pushNamed(
            RouteNames.subjectDetail,
            pathParameters: {'id': '${subject.id}'},
          ),
        );
      },
    );
  }
}