import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lectra/core/utils/subject_lookup.dart';
import 'package:lectra/features/attendance/controller.dart';
import 'package:lectra/features/attendance/model.dart';
import 'package:lectra/features/subjects/controller.dart';
import 'package:lectra/shared/widgets/attendance_pie_chart.dart';
import 'package:go_router/go_router.dart';
import 'package:lectra/core/constants/route_paths.dart';

/// Detailed attendance view for a single subject: an overall pie
/// chart with counts, and a toggle between a history list and a
/// per-day calendar view.
class SubjectDetailScreen extends ConsumerStatefulWidget {
  const SubjectDetailScreen({required this.subjectId, super.key});

  final int subjectId;

  @override
  ConsumerState<SubjectDetailScreen> createState() =>
      _SubjectDetailScreenState();
}

class _SubjectDetailScreenState extends ConsumerState<SubjectDetailScreen> {
  bool _showCalendar = false;
  DateTime _visibleMonth = DateTime(DateTime.now().year, DateTime.now().month);

  @override
  Widget build(BuildContext context) {
    final subjects = ref.watch(subjectsControllerProvider).valueOrNull ?? [];
    final subject = findSubjectById(subjects, widget.subjectId);
    final statsAsync = ref.watch(subjectAttendanceStatsProvider(widget.subjectId));
    final recordsAsync =
        ref.watch(subjectAttendanceRecordsProvider(widget.subjectId));

    return Scaffold(
      appBar: AppBar(
        title: Text(subject?.displayName ?? 'Subject'),
        actions: [
  IconButton(
    icon: const Icon(Icons.edit_outlined),
    tooltip: 'Edit subject',
    onPressed: () => context.pushNamed(
      RouteNames.editSubject,
      pathParameters: {'id': '${widget.subjectId}'},
    ),
  ),
  IconButton(
    icon: Icon(_showCalendar ? Icons.list : Icons.calendar_month),
    onPressed: () => setState(() => _showCalendar = !_showCalendar),
  ),
],
      ),
      body: subject == null
          ? const Center(child: CircularProgressIndicator())
          : statsAsync.when(
              data: (stats) => _showCalendar
                  ? _CalendarView(
                      subjectId: widget.subjectId,
                      subjectColor: subject.accentColor,
                      visibleMonth: _visibleMonth,
                      onMonthChanged: (m) => setState(() => _visibleMonth = m),
                      records: recordsAsync.valueOrNull ?? [],
                    )
                  : _HistoryList(
                      stats: stats,
                      subjectColor: subject.accentColor,
                      records: recordsAsync.valueOrNull ?? [],
                    ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stackTrace) => Center(child: Text('Error: $error')),
            ),
    );
  }
}

class _HistoryList extends StatelessWidget {
  const _HistoryList({
    required this.stats,
    required this.subjectColor,
    required this.records,
  });

  final SubjectAttendanceStats stats;
  final Color subjectColor;
  final List<AttendanceRecordItem> records;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: AttendancePieChart(
            percentage: stats.percentage,
            size: 120,
            color: subjectColor,
          ),
        ),
        const SizedBox(height: 16),
        _StatRow(label: 'Total classes', value: stats.total),
        _StatRow(label: 'Present', value: stats.present),
        _StatRow(label: 'Absent', value: stats.absent),
        _StatRow(label: 'Cancelled', value: stats.cancelled),
        const SizedBox(height: 16),
        if (records.isNotEmpty)
          const Text('History', style: TextStyle(fontWeight: FontWeight.bold)),
        for (final record in records)
          ListTile(
            leading: Icon(_iconFor(record.status)),
            title: Text(_formatDate(record.date)),
            trailing: Text(record.status.name),
          ),
      ],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';
  }

  IconData _iconFor(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return Icons.check_circle_outline;
      case AttendanceStatus.absent:
        return Icons.cancel_outlined;
      case AttendanceStatus.cancelled:
        return Icons.event_busy_outlined;
    }
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text('$value', style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _CalendarView extends ConsumerWidget {
  const _CalendarView({
    required this.subjectId,
    required this.subjectColor,
    required this.visibleMonth,
    required this.onMonthChanged,
    required this.records,
  });

  final int subjectId;
  final Color subjectColor;
  final DateTime visibleMonth;
  final ValueChanged<DateTime> onMonthChanged;
  final List<AttendanceRecordItem> records;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final firstDay = DateTime(visibleMonth.year, visibleMonth.month, 1);
    final daysInMonth =
        DateTime(visibleMonth.year, visibleMonth.month + 1, 0).day;
    final leadingBlanks = firstDay.weekday - 1;
    final recordsByDay = {
      for (final r in records) DateTime(r.date.year, r.date.month, r.date.day): r.status,
    };

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              icon: const Icon(Icons.chevron_left),
              onPressed: () => onMonthChanged(
                DateTime(visibleMonth.year, visibleMonth.month - 1),
              ),
            ),
            Text(
              '${visibleMonth.year}-${visibleMonth.month.toString().padLeft(2, '0')}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: () => onMonthChanged(
                DateTime(visibleMonth.year, visibleMonth.month + 1),
              ),
            ),
          ],
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
            itemCount: leadingBlanks + daysInMonth,
            itemBuilder: (context, index) {
              if (index < leadingBlanks) return const SizedBox.shrink();
              final day = index - leadingBlanks + 1;
              final date = DateTime(visibleMonth.year, visibleMonth.month, day);
              final status = recordsByDay[date];
              return GestureDetector(
                onTap: () => _showMarkDialog(context, ref, date),
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: _colorFor(status, context),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Text('$day'),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Color _colorFor(AttendanceStatus? status, BuildContext context) {
    switch (status) {
      case AttendanceStatus.present:
        return subjectColor.withValues(alpha: 0.35);
      case AttendanceStatus.absent:
        return Theme.of(context).colorScheme.errorContainer;
      case AttendanceStatus.cancelled:
        return Theme.of(context).colorScheme.surfaceContainerHighest;
      case null:
        return Colors.transparent;
    }
  }

  Future<void> _showMarkDialog(
    BuildContext context,
    WidgetRef ref,
    DateTime date,
  ) async {
    final status = await showDialog<AttendanceStatus?>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: Text(
          '${date.year}-${date.month.toString().padLeft(2, '0')}-'
          '${date.day.toString().padLeft(2, '0')}',
        ),
        children: [
          SimpleDialogOption(
            onPressed: () =>
                Navigator.of(dialogContext).pop(AttendanceStatus.present),
            child: const Text('Present'),
          ),
          SimpleDialogOption(
            onPressed: () =>
                Navigator.of(dialogContext).pop(AttendanceStatus.absent),
            child: const Text('Absent'),
          ),
          SimpleDialogOption(
            onPressed: () =>
                Navigator.of(dialogContext).pop(AttendanceStatus.cancelled),
            child: const Text('Cancelled'),
          ),
        ],
      ),
    );
    if (status == null) return;
    await ref.read(attendanceMarkingControllerProvider.notifier).markAttendance(
          subjectId: subjectId,
          date: date,
          status: status,
        );
  }
}