/// Route path and name constants used by [AppRouter].
///
/// Keeping these in one place prevents typo-driven navigation bugs
/// and magic strings inside the routing configuration.
abstract final class RoutePaths {
  static const String dashboard = '/dashboard';
  static const String subjects = '/subjects';
  static const String settings = '/settings';
  static const String subjectDetailSegment = ':id';
}

/// Route name constants, used with `context.goNamed`/`pushNamed`.
abstract final class RouteNames {
  static const String dashboard = 'dashboard';
  static const String subjects = 'subjects';
  static const String subjectDetail = 'subjectDetail';
  static const String settings = 'settings';
}