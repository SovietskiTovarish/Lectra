import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lectra/core/utils/subject_lookup.dart';
import 'package:lectra/features/attendance/controller.dart';
import 'package:lectra/features/attendance/model.dart';
import 'package:lectra/features/subjects/controller.dart';
import 'package:lectra/features/subjects/model.dart';
import 'package:lectra/features/timetable/controller.dart';
import 'package:lectra/features/timetable/model.dart';
import 'package:lectra/shared/widgets/attendance_pie_chart.dart';

/// Home dashboard showing today's scheduled lectures.
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final timetableAsync = ref.watch(timetableControllerProvider);
    final subjects =
        ref.watch(subjectsControllerProvider).valueOrNull ?? const <SubjectItem>[];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Today'),
      ),
      body: timetableAsync.when(
        loading: () => const Center(
          child: CircularProgressIndicator(),
        ),
        error: (error, _) => Center(
          child: Text(error.toString()),
        ),
        data: (entries) {
          final weekday = DateTime.now().weekday;

          final todaysEntries = entries
              .where((e) => e.dayOfWeek == weekday)
              .toList()
            ..sort(
              (a, b) => a.startMinutes.compareTo(
                b.startMinutes,
              ),
            );

          if (todaysEntries.isEmpty) {
            return const Center(
              child: Text(
                'No lectures scheduled for today.',
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: todaysEntries.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final lecture = todaysEntries[index];

              final subject = findSubjectById(
                subjects,
                lecture.subjectId,
              );

              return _TodayClassCard(
                entry: lecture,
                subject: subject,
              );
            },
          );
        },
      ),
    );
  }
}

class _TodayClassCard extends ConsumerWidget {
  const _TodayClassCard({
    required this.entry,
    required this.subject,
  });

  final TimetableEntryItem entry;
  final SubjectItem? subject;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(
      subjectAttendanceStatsProvider(
        entry.subjectId,
      ),
    );

    final percentage =
        statsAsync.valueOrNull?.percentage ?? 0;

    final color =
        subject?.accentColor ??
            Theme.of(context).colorScheme.primary;

    final title =
        subject?.displayName ?? entry.subjectName;

    return Card(
      child: ListTile(
        leading: AttendancePieChart(
          percentage: percentage,
          size: 48,
          color: color,
        ),
        title: Text(title),
        subtitle: Text(
          '${entry.startLabel} – ${entry.endLabel}'
          '${entry.room.isNotEmpty ? ' • ${entry.room}' : ''}',
        ),
        trailing: const Icon(
          Icons.chevron_right,
        ),
        onTap: () => _showAttendanceSheet(
          context,
          ref,
          title,
          color,
          percentage,
        ),
      ),
    );
  }

  void _showAttendanceSheet(
    BuildContext context,
    WidgetRef ref,
    String title,
    Color color,
    double percentage,
  ) {
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: Theme.of(sheetContext)
                    .textTheme
                    .titleLarge,
              ),
              const SizedBox(height: 20),
              AttendancePieChart(
                percentage: percentage,
                size: 96,
                color: color,
              ),
              const SizedBox(height: 24),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  FilledButton(
                    onPressed: () => _mark(
                      ref,
                      sheetContext,
                      AttendanceStatus.present,
                    ),
                    child: const Text('Present'),
                  ),
                  OutlinedButton(
                    onPressed: () => _mark(
                      ref,
                      sheetContext,
                      AttendanceStatus.absent,
                    ),
                    child: const Text('Absent'),
                  ),
                  OutlinedButton(
                    onPressed: () => _mark(
                      ref,
                      sheetContext,
                      AttendanceStatus.cancelled,
                    ),
                    child: const Text('Cancelled'),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _mark(
    WidgetRef ref,
    BuildContext context,
    AttendanceStatus status,
  ) {
    ref
        .read(
          attendanceMarkingControllerProvider.notifier,
        )
        .markAttendance(
          subjectId: entry.subjectId,
          date: DateTime.now(),
          status: status,
        );

    Navigator.pop(context);
  }
}