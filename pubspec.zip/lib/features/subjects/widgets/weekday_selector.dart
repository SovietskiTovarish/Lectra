import 'package:flutter/material.dart';

class WeekdaySelector extends StatelessWidget {
  const WeekdaySelector({
    super.key,
    required this.selectedDays,
    required this.onChanged,
  });

  final Set<int> selectedDays;

  final ValueChanged<Set<int>> onChanged;

  static const List<String> labels = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(
        7,
        (index) {
          final day = index + 1;

          final selected =
              selectedDays.contains(day);

          return FilterChip(
            label: Text(labels[index]),
            selected: selected,
            onSelected: (_) {
              final updated =
                  Set<int>.from(selectedDays);

              if (selected) {
                updated.remove(day);
              } else {
                updated.add(day);
              }

              onChanged(updated);
            },
          );
        },
      ),
    );
  }
}