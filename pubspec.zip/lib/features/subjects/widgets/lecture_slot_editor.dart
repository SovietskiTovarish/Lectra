import 'package:flutter/material.dart';
import 'package:lectra/features/subjects/models/lecture_slot_form.dart';
import 'package:lectra/features/subjects/widgets/weekday_selector.dart';

/// Editor for a single recurring lecture slot.
///
/// Used by the Add/Edit Subject screen.
class LectureSlotEditor extends StatelessWidget {
  const LectureSlotEditor({
    super.key,
    required this.slot,
    required this.onChanged,
    required this.onDelete,
    required this.index,
  });

  final LectureSlotForm slot;

  final int index;

  final ValueChanged<LectureSlotForm> onChanged;

  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Lecture Slot ${index + 1}',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const Spacer(),
                IconButton(
                  tooltip: 'Delete Lecture Slot',
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),

            const SizedBox(height: 12),

            const Text(
              'Days',
              style: TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 8),

            WeekdaySelector(
              selectedDays: slot.weekdays,
              onChanged: (days) {
                onChanged(
                  slot.copyWith(
                    weekdays: days,
                  ),
                );
              },
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: _TimeTile(
                    title: 'Start',
                    value: slot.startTime,
                    onChanged: (time) {
                      onChanged(
                        slot.copyWith(
                          startTime: time,
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _TimeTile(
                    title: 'End',
                    value: slot.endTime,
                    onChanged: (time) {
                      onChanged(
                        slot.copyWith(
                          endTime: time,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            TextFormField(
              initialValue: slot.room,
              decoration: const InputDecoration(
                labelText: 'Room',
                hintText: 'e.g. LH-204',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                onChanged(
                  slot.copyWith(
                    room: value,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeTile extends StatelessWidget {
  const _TimeTile({
    required this.title,
    required this.value,
    required this.onChanged,
  });

  final String title;

  final TimeOfDay value;

  final ValueChanged<TimeOfDay> onChanged;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: () async {
        final picked = await showTimePicker(
          context: context,
          initialTime: value,
        );

        if (picked != null) {
          onChanged(picked);
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 14,
        ),
        child: Column(
          children: [
            Text(title),
            const SizedBox(height: 6),
            Text(
              value.format(context),
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}