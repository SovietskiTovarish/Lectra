import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lectra/core/constants/route_paths.dart';
import 'package:lectra/core/theme/subject_colors.dart';
import 'package:lectra/features/attendance/controller.dart';
import 'package:lectra/features/subjects/controller.dart';
import 'package:lectra/features/subjects/model.dart';
import 'package:lectra/features/timetable/controller.dart';
import 'package:lectra/features/timetable/model.dart';
import 'package:lectra/shared/widgets/attendance_pie_chart.dart';

/// Lists all subjects with their overall attendance percentage and
/// opens the subject detail route when tapped.
class SubjectsScreen extends ConsumerWidget {
  const SubjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final subjectsAsync = ref.watch(subjectsControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Subjects')),
      body: subjectsAsync.when(
        data: (subjects) => _SubjectsList(subjects: subjects),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => Center(child: Text('Error: $error')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showDialog<void>(
          context: context,
          builder: (_) => const _AddSubjectDialog(),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _SubjectsList extends ConsumerWidget {
  const _SubjectsList({required this.subjects});

  final List<SubjectItem> subjects;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (subjects.isEmpty) {
      return const Center(child: Text('No subjects yet. Tap + to add one.'));
    }
    return ListView.builder(
      itemCount: subjects.length,
      itemBuilder: (context, index) {
        final subject = subjects[index];
        final statsAsync = ref.watch(subjectAttendanceStatsProvider(subject.id));
        final percentage = statsAsync.valueOrNull?.percentage ?? 0;
        return ListTile(
          leading: AttendancePieChart(
            percentage: percentage,
            size: 44,
            color: subject.color,
          ),
          title: Text(subject.displayName),
          subtitle: subject.nickname != null && subject.nickname!.isNotEmpty
              ? Text(subject.name)
              : null,
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => ref
                .read(subjectsControllerProvider.notifier)
                .deleteSubject(subject.id),
          ),
          onTap: () => context.pushNamed(
            RouteNames.subjectDetail,
            pathParameters: {'id': '${subject.id}'},
          ),
        );
      },
    );
  }
}

class _AddSubjectDialog extends ConsumerStatefulWidget {
  const _AddSubjectDialog();

  @override
  ConsumerState<_AddSubjectDialog> createState() => _AddSubjectDialogState();
}

class _AddSubjectDialogState extends ConsumerState<_AddSubjectDialog> {
  final _nameController = TextEditingController();
  final _nicknameController = TextEditingController();
  int _dayOfWeek = 1;
  TimeOfDay _start = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 10, minute: 0);
  int? _colorValue;

  @override
  void dispose() {
    _nameController.dispose();
    _nicknameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Subject'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
              autofocus: true,
            ),
            TextField(
              controller: _nicknameController,
              decoration:
                  const InputDecoration(labelText: 'Nickname (optional)'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              initialValue: _dayOfWeek,
              decoration: const InputDecoration(labelText: 'Day'),
              items: List.generate(
                TimetableEntryItem.weekdayNames.length,
                (i) => DropdownMenuItem(
                  value: i + 1,
                  child: Text(TimetableEntryItem.weekdayNames[i]),
                ),
              ),
              onChanged: (value) => setState(() => _dayOfWeek = value!),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Start time'),
              trailing: Text(_start.format(context)),
              onTap: () => _pickTime(isStart: true),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('End time'),
              trailing: Text(_end.format(context)),
              onTap: () => _pickTime(isStart: false),
            ),
            const SizedBox(height: 8),
            const Text('Accent colour'),
            const SizedBox(height: 8),
            _ColorPicker(
              selected: _colorValue,
              onSelected: (value) => setState(() => _colorValue = value),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(onPressed: _submit, child: const Text('Add')),
      ],
    );
  }

  Future<void> _pickTime({required bool isStart}) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: isStart ? _start : _end,
    );
    if (picked == null) return;
    setState(() => isStart ? _start = picked : _end = picked);
  }

  Future<void> _submit() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;
    final startMinutes = _start.hour * 60 + _start.minute;
    final endMinutes = _end.hour * 60 + _end.minute;
    if (endMinutes <= startMinutes) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('End time must be after start time')),
      );
      return;
    }
    final nickname = _nicknameController.text.trim();
    final subjectId =
        await ref.read(subjectsControllerProvider.notifier).addSubject(
              name: name,
              nickname: nickname.isEmpty ? null : nickname,
              colorValue: _colorValue,
            );
    await ref.read(timetableControllerProvider.notifier).addEntry(
          subjectId: subjectId,
          dayOfWeek: _dayOfWeek,
          startMinutes: startMinutes,
          endMinutes: endMinutes,
        );
    if (mounted) Navigator.of(context).pop();
  }
}

class _ColorPicker extends StatelessWidget {
  const _ColorPicker({required this.selected, required this.onSelected});

  final int? selected;
  final ValueChanged<int?> onSelected;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        for (final value in SubjectColors.palette)
          GestureDetector(
            onTap: () => onSelected(value),
            child: CircleAvatar(
              radius: 16,
              backgroundColor: Color(value),
              child: selected == value
                  ? const Icon(Icons.check, color: Colors.white, size: 18)
                  : null,
            ),
          ),
        ActionChip(
          label: const Text('Auto'),
          onPressed: () => onSelected(null),
          backgroundColor: selected == null
              ? Theme.of(context).colorScheme.secondaryContainer
              : null,
        ),
      ],
    );
  }
}